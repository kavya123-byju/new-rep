# Web322 Assignment

Student Name: Kavya Byju 
Student Number:  155142227
Student Email:  kbyju@myseneca.ca
Date Created:  23 September 2024

GITHUB URL:  https://github.com/kavya123-byju/new-rep.git
VERCEL URL:  web322assignments-five.vercel.app
            web322assignments-git-master-kavya-byjus-projects.vercel.app
            web322assignments-cgcisxk0q-kavya-byjus-projects.vercel.app
### Technology Stack

**Frontend**:    
**Backend**: Node.js, Express.js  
**Database**: TBD  

### Notes

By submitting this as my assignment, I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of this assignment has been copied manually or electronically from any other source (including web sites) or distributed to other students.
